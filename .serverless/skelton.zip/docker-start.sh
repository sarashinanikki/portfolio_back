#!/bin/sh
docker compose up